package com.boxuegu.utils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyDataBaseHelper extends SQLiteOpenHelper {
    public MyDataBaseHelper(@Nullable Context context) {
        super(context, "info", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql="create table info(id integer primary key autoincrement,"+
                "username varchar(50),"+
                "pwd varchar(128),"+
                "security varchar(50),"+
                "isLogin boolean)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
