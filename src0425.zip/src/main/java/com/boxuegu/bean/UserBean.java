package com.boxuegu.bean;

public class UserBean {
    public String userName;
    public String nickName;
    public String sex;
    public String signature;

}
