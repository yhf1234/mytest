package com.boxuegu.bean;

public class CourseBean {
    public int id;          //每章Id
    public String imgTitle; //图片上的标题
    public String title;    //章标题
    public String intro;    //章视频简介
    public String icon;     //广告栏上的图片
}
