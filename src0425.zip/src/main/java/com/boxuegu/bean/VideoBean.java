package com.boxuegu.bean;

public class VideoBean {
    public int chapterId;           //章节ID
    public int videoId;             //视频ID
    public String title;            //章节标题
    public String secondTitle;      //视频标题
    public String videoPath;        //视频播放地址
}
