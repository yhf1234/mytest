package com.boxuegu.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.boxuegu.R;
import com.boxuegu.utils.MD5Utils;
import com.boxuegu.utils.MyDataBaseHelper;

public class LoginActivity extends AppCompatActivity {

    private TextView tv_main_title;
    private TextView tv_back;
    private TextView tv_register;
    private TextView tv_find_psw;
    private Button btn_login;
    private EditText et_user_name;
    private EditText et_psw;
    private String userName,psw,spPsw;
    MyDataBaseHelper helper;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
    }
    private void init(){
        tv_main_title =(TextView)findViewById(R.id.tv_main_title);
        tv_main_title.setText("登录");
        tv_back =(TextView)findViewById(R.id.tv_back);
        tv_register =(TextView)findViewById(R.id.tv_register);
        tv_find_psw =(TextView)findViewById(R.id.tv_find_psw);
        btn_login =(Button)findViewById(R.id.btn_login);
        et_user_name =(EditText)findViewById(R.id.et_user_name);
        et_psw =(EditText)findViewById(R.id.et_psw);
        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginActivity.this.finish();
            }
        });
        tv_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginActivity.this,RegisterActivity.class);
                startActivityForResult(intent,1);
            }
        });
        tv_find_psw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到找回密码界面
                Intent intent=new Intent(LoginActivity.this,FindPswActivity.class);
                startActivity(intent);
            }
        });
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userName=et_user_name.getText().toString().trim();
                psw=et_psw.getText().toString().trim();
                String md5Psw= MD5Utils.md5(psw);
                spPsw= readPsw(userName);
                if(TextUtils.isEmpty(userName)){
                    Toast.makeText(LoginActivity.this, "请输入用户名", Toast.LENGTH_SHORT).show();
                    return;
                }else if(TextUtils.isEmpty(psw)){
                    Toast.makeText(LoginActivity.this, "请输入密码", Toast.LENGTH_SHORT).show();
                    return;
                }else if(md5Psw.equals(spPsw)){
                    Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                    saveLoginStatus(true,userName);
                    Intent data=new Intent();
                    data.putExtra("isLogin",true);
                    setResult(RESULT_OK,data);
                    LoginActivity.this.finish();
                    return;
                }else if(spPsw!=null&&!TextUtils.isEmpty(spPsw)&&!md5Psw.equals(spPsw)){
                    Toast.makeText(LoginActivity.this, "输入的用户名和密码不一致", Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    Toast.makeText(LoginActivity.this, "此用户名不存在", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    /*
    * 从SQLite中根据用户名读取密码
    * */
    private String readPsw(String userName){
        String pwd="";
        final MyDataBaseHelper helper=new MyDataBaseHelper(this);//作用解决getReadableDatabase()和getWritableDatabase()等报错问题
        db=helper.getReadableDatabase();
        Cursor cursor = db.query("info", new String[]{"pwd"}, "username=?", new String[]{userName}, null, null, null);
        while (cursor.moveToNext()){
            pwd=cursor.getString(0);
            break;
        }
        db.close();
        return pwd;
        /*SharedPreferences sharedPreferences=getSharedPreferences("userInfo",MODE_PRIVATE);
        return sharedPreferences.getString(userName,"");*/
    }
    /*
    * 保存登录状态和登录用名到SQLite中
    * */
    private void saveLoginStatus(boolean status,String userName){
        final MyDataBaseHelper helper=new MyDataBaseHelper(this);//作用解决getReadableDatabase()和getWritableDatabase()等报错问题
        String md5Psw= MD5Utils.md5(psw);
        db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("isLogin",status);
        // values.put("username",userName);
        db.update("info",values,"username=?",new String[]{userName});
        db.close();
        /*SharedPreferences sharedPreferences=getSharedPreferences("loginInfo",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putBoolean("isLogin",status);
        editor.putString("loginUserName",userName);
        editor.commit();*/
    }
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(data!=null){
            String userName=data.getStringExtra("username");
            if(!TextUtils.isEmpty(userName)){
                et_user_name.setText(userName);
                et_user_name.setSelection(userName.length());
            }
        }
    }
}
