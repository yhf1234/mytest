package com.boxuegu.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.boxuegu.R;
import com.boxuegu.utils.AnalysisUtils;
import com.boxuegu.utils.MD5Utils;
import com.boxuegu.utils.MyDataBaseHelper;

public class ModifyPswActivity extends AppCompatActivity {

    private String userName;
    private TextView tv_main_title;
    private TextView tv_back;
    private EditText et_original_psw;
    private EditText et_new_psw;
    private EditText et_new_psw_again;
    private Button btn_save;
    private String originalPsw,newPsw,newPswAgain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_psw);
        init();
        userName =AnalysisUtils.readLoginUserName(this);
    }
    /**
     * 获取界面控件并处理相关控件的点击事件
     */
    private void init(){
        tv_main_title =(TextView)findViewById(R.id.tv_main_title);
        tv_main_title.setText("修改密码");
        tv_back =(TextView)findViewById(R.id.tv_back);
        et_original_psw =(EditText)findViewById(R.id.et_original_psw);
        et_new_psw =(EditText)findViewById(R.id.et_new_psw);
        et_new_psw_again =(EditText)findViewById(R.id.et_new_psw_again);
        btn_save =(Button)findViewById(R.id.btn_save);
        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ModifyPswActivity.this.finish();
            }
        });
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getEditString();
                Log.e("error","2:"+MD5Utils.md5(originalPsw));
                Log.e("error","3:"+MD5Utils.md5(newPsw));
                Log.e("error","4:"+MD5Utils.md5(newPswAgain));
                if (TextUtils.isEmpty(originalPsw)){
                    Toast.makeText(ModifyPswActivity.this, "请输入原始密码", Toast.LENGTH_SHORT).show();
                    return;
                }else if (!MD5Utils.md5(originalPsw).equals(readPsw())){
                    Toast.makeText(ModifyPswActivity.this, "输入的密码与原始密码不一致", Toast.LENGTH_SHORT).show();
                    return;
                }else if (MD5Utils.md5(newPsw).equals(readPsw())){
                    Toast.makeText(ModifyPswActivity.this, "输入的新密码与原始密码不能一致", Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(newPsw)){
                    Toast.makeText(ModifyPswActivity.this, "请输入新密码", Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(newPswAgain)){
                    Toast.makeText(ModifyPswActivity.this, "请再次输入新密码", Toast.LENGTH_SHORT).show();
                    return;
                }else if (!newPsw.equals(newPswAgain)){
                    Toast.makeText(ModifyPswActivity.this, "两次输入的新密码不一致", Toast.LENGTH_SHORT).show();
                    return;
                }else {
                    Toast.makeText(ModifyPswActivity.this, "新密码设置成功", Toast.LENGTH_SHORT).show();
                    modifyPsw(newPsw);
                    Intent intent=new Intent(ModifyPswActivity.this,LoginActivity.class);
                    startActivity(intent);
                    SettingActivity.instance.finish();
                    ModifyPswActivity.this.finish();
                }
            }
        });
    }
    /**
     * 获取控件上的字符串
     * */
    private void getEditString(){
        originalPsw=et_original_psw.getText().toString().trim();
        newPsw=et_new_psw.getText().toString().trim();
        newPswAgain=et_new_psw_again.getText().toString().trim();
    }
    /**
     * 修改登录成功是保存在sqlite中的密码
     *
     * @param newPsw*/
    private void modifyPsw(String newPsw){
        String md5Psw=MD5Utils.md5(this.newPsw);
        final MyDataBaseHelper helper=new MyDataBaseHelper(this);
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("pwd",md5Psw);
        db.update("info",values,"username=?",new String[]{userName});
        db.close();
    }
    private String readPsw(){
        String spSpw="";
        final MyDataBaseHelper helper=new MyDataBaseHelper(this);
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cursor = db.query("info", new String[]{"pwd"}, "username=?", new String[]{userName}, null, null, null);
        while (cursor.moveToNext()){
            spSpw=cursor.getString(0);
            break;
        }
        Log.e("error","1:"+spSpw);
        db.close();
        return spSpw;

    }
}
